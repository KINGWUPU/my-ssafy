const a = 30;
const b = 50;

module.exports = {
    a, b
};