const sum = require('./sum.js');
const member = require('./member.js');

a = member.a;
b = member.b;

console.log(sum.sum(a,b))