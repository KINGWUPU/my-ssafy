function sum(x,y) {
    return x+y;
}

module.exports = {
    sum
};